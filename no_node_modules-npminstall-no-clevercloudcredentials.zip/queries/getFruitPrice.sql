SELECT name, price, image FROM fruits WHERE name = ?;

